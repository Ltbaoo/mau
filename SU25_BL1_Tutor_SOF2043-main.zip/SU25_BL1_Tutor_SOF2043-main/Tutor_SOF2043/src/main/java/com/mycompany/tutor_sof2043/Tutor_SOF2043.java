/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tutor_sof2043;

/**
 *
 * @author Huyen
 */
public class Tutor_SOF2043 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
