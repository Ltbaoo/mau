/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import lombok.*;

/**
 *
 * @author Huyen
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Drink {

    private String id;//giả sử int -> trong db lại là id tự tăng-> check DB??
    private String name;
    @Builder.Default
    private String image = "product.png";
    private double unitPrice;
    private double discount;
    private boolean available;
    private String categoryId;
    
}
